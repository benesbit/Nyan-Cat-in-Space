#pragma once

#include "ofMain.h"

const int NUMBER_OF_STARS = 350;
const int NUMBER_OF_PLANETS = 5;
const int MAX_NUMBER_OF_LASERS = 10;
const int WINDOW_HEIGHT = 768;
const int WINDOW_WIDTH = 1024;
const int MAX_STAR_SPEED = 3;
const int MAX_STAR_RADIUS = 4;
const int ENEMY_FIRE_RATE = 300;
const int PLANET_SPAWN_RATE = 350;
const float PLAYER_ACCELERATION = 0.1;
const float ENEMY_ACCELERATION = 0.097;

class ofApp : public ofBaseApp {

public:

	struct star** stars;
	ofImage** planets;
	struct planet* aPlanet;
	struct ship* nyanShip;
	struct ship* enemyShip;
	struct score* playerScore;
	struct laser** playerShots;
	struct laser** enemyShots;
	int* laserCounter;
	int* enemyLaserCounter;
	int* enemyShotTimer;
	ofImage nyan;
	ofImage rainbow;
	ofImage tacNyan;
	ofImage graybow;
	ofImage orangePlanet;
	ofImage purplePlanet;
	ofImage moonPlanet;
	ofImage earthPlanet;
	ofImage waterPlanet;
	ofTrueTypeFont scoreFont;

	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);
};
